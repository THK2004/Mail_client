#pragma once
#include <iostream>
#include <string>
#include <vector>

#define BUFFER_SIZE 1024

using namespace std;